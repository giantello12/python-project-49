### Hexlet tests and linter status:
[![Actions Status](https://github.com/giantello12/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/giantello12/python-project-49/actions)

<a href="https://codeclimate.com/github/giantello12/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/259cf238e5b3fc8f2e13/maintainability" /></a>

<h2>brain-even asciinema<h2>
<a href="https://asciinema.org/a/PVqSVKYu0PsrbtGqmEm6q70d7" target="_blank"><img src="https://asciinema.org/a/PVqSVKYu0PsrbtGqmEm6q70d7.svg" /></a>

<h2>brain-calc asciinema<h2>
<a href="https://asciinema.org/a/R9W2zY6MwaJZg4q3bLpts9AIn" target="_blank"><img src="https://asciinema.org/a/R9W2zY6MwaJZg4q3bLpts9AIn.svg" /></a>